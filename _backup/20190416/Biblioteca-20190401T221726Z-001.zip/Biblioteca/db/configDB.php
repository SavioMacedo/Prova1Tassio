<?php
/**
 * Created by PhpStorm.
 * User: tassio
 * Date: 2019-03-16
 * Time: 15:10
 */

define("HOSTNAME","localhost");
define("USER","root");
define("PASS","root");
define("DRIVER","mysql");
define("DBNAME","biblioteca");
define('CHARSET', 'utf8');
//define("PORT","3306");

?>