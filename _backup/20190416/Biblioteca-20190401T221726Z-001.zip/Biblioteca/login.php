<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Logar no Sistema</title>
</head>
<body>
<form method="post" action="logar.php" id="formlogin" name="formlogin" >
    <fieldset id="fie">
        <legend>LOGIN</legend><br />
        <label>NOME : </label>
        <input type="text" name="login" id="login"  /><br />
        <label>SENHA :</label>
        <input type="password" name="senha" id="senha" /><br />
        <input type="submit" value="LOGAR" />
    </fieldset>
</form>
</body>
</html>